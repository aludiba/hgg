//
//  AppDelegate.h
//  MagicImage
//
//  Created by MagicImage on 2019/4/25.
//  Copyright © 2019 April. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

