//
//  MIReturnFormat.m
//  LookScore
//
//  Created by wr on 2018/1/17.
//  Copyright © 2018年 ChongQingXunTiCompany. All rights reserved.
//

#import "MIReturnFormat.h"

@implementation MIReturnFormat

@end
