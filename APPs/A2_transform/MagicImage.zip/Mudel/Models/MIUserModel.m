//
//  MIUserModel.m
//  MagicImage
//
//  Created by MagicImage on 2019/5/1.
//  Copyright © 2019 April. All rights reserved.
//

#import "MIUserModel.h"

@implementation MIUserModel

@end
