//
//  MITagsDetailVC.h
//  MagicImage
//
//  Created by woqingke on 2019/5/2.
//  Copyright © 2019 April. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MITagsDetailVC : UIViewController
@property (nonatomic, assign) NSInteger tagId;

@end

NS_ASSUME_NONNULL_END
