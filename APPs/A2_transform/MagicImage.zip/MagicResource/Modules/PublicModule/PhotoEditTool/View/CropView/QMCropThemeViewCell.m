//
//  QMCropThemeViewCell.m
//  EnjoyCamera
//
//  Created by qinmin on 2017/9/5.
//  Copyright © 2017年 qinmin. All rights reserved.
//

#import "QMCropThemeViewCell.h"

@implementation QMCropThemeViewCell

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.label.textColor = [UIColor whiteColor];
}

@end
