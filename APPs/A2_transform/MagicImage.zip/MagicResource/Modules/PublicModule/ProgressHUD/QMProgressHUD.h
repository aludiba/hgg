//
//  QMHUDProgress.h
//  EnjoyCamera
//
//  Created by qinmin on 2017/9/19.
//  Copyright © 2017年 qinmin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QMProgressHUD : NSObject

+ (void)show;
+ (void)hide;

@end
