//
//  MIUserModel.h
//  MagicImage
//
//  Created by MagicImage on 2019/5/1.
//  Copyright © 2019 April. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MIUserModel : NSObject
@property (nonatomic, copy) NSString * contact_us_eamil;
@property (nonatomic, copy) NSString * create_time;
@property (nonatomic, copy) NSString * equipment_id;
@property (nonatomic, copy) NSString * id;
@property (nonatomic, copy) NSString * peanut_num;
@property (nonatomic, copy) NSString * rateus_jump_url;
@property (nonatomic, copy) NSString * share_content;
@property (nonatomic, copy) NSString * share_pic;
@property (nonatomic, copy) NSString * share_title;
@property (nonatomic, copy) NSString * update_time;
@property (nonatomic, copy) NSArray * cycle_pic;
@end

NS_ASSUME_NONNULL_END
