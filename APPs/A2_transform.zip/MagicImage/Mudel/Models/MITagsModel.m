//
//  MITagsModel.m
//  MagicImage
//
//  Created by MagicImage on 2019/5/1.
//  Copyright © 2019 April. All rights reserved.
//

#import "MITagsModel.h"

@implementation MITagsModel

@end
