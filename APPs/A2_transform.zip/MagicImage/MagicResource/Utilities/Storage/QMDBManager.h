//
//  QMDBManager.h
//  EnjoyCamera
//
//  Created by qinmin on 2017/10/3.
//  Copyright © 2017年 qinmin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QMDBManager : NSObject

+ (instancetype)shareManager;

@end
