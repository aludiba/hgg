//
//  QMBaseNavigationController.h
//  EnjoyCamera
//
//  Created by qinmin on 2017/8/21.
//  Copyright © 2017年 qinmin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QMBaseNavigationController : UINavigationController

@end
