//
//  UIImage+mask.h
//  EnjoyCamera
//
//  Created by qinmin on 2017/4/13.
//  Copyright © 2017年 qinmin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Masking)

-(UIImage*)maskWithImage:(UIImage*)maskImage;

@end
