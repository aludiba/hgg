//
//  QMFrameThemeViewCell.m
//  EnjoyCamera
//
//  Created by qinmin on 2017/9/19.
//  Copyright © 2017年 qinmin. All rights reserved.
//

#import "QMFrameThemeViewCell.h"

@implementation QMFrameThemeViewCell

- (void)awakeFromNib
{
    [super awakeFromNib];
//    self.label.textColor = [UIColor whiteColor];
}

@end
