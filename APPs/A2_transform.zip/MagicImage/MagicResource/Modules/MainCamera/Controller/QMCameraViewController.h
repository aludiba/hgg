//
//  QMCameraViewController.h
//  EnjoyCamera
//
//  Created by qinmin on 2017/4/13.
//  Copyright © 2017年 qinmin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constants.h"

@interface QMCameraViewController : UIViewController

@end
