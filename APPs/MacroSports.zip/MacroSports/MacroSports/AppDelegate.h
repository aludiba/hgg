//
//  AppDelegate.h
//  MacroSports
//
//  Created by user on 2020/6/30.
//  Copyright © 2020 macro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic)UIWindow *LBwindow;
@end

