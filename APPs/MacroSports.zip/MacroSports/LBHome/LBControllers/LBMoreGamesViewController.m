//
//  LBMoreGamesViewController.m
//  MacroSports
//
//  Created by user on 2020/7/4.
//  Copyright © 2020 macro. All rights reserved.
//

#import "LBMoreGamesViewController.h"

@interface LBMoreGamesViewController ()

@end

@implementation LBMoreGamesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"比赛列表";
}

@end
