//
//  LBHomeViewController.h
//  MacroSports
//
//  Created by user on 2020/7/4.
//  Copyright © 2020 macro. All rights reserved.
//

#import "LBBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LBHomeViewController : LBBaseViewController

@end

NS_ASSUME_NONNULL_END
