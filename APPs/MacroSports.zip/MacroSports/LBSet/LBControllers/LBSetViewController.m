//
//  LBSetViewController.m
//  MacroSports
//
//  Created by user on 2020/7/4.
//  Copyright © 2020 macro. All rights reserved.
//

#import "LBSetViewController.h"

@interface LBSetViewController ()

@end

@implementation LBSetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"个人中心";
}

@end
